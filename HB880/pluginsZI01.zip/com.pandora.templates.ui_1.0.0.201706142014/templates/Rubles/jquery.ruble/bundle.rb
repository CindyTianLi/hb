require 'ruble'

bundle do |bundle|
  bundle.display_name = t(:bundle_name)
  bundle.author = ''
  bundle.contact_email_rot_13 = ''
  bundle.description ='Support for the <a href="http://jquery.com/">jQuery JavaScript library</a>.'
  bundle.repository = ''
  
end
