require 'ruble'

bundle t(:bundle_name) do |bundle|
  bundle.author = ''
  bundle.contact_email_rot_13 = ''
  bundle.repository = ""
  bundle.description =  '<a href="http://www.php.net/">PHP</a> is a widely-used general-purpose scripting language that is especially suited for web development and can be embedded into HTML.'
  
end
