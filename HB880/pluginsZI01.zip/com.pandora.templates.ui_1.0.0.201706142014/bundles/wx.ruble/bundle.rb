require 'ruble'
 
# its ruby, so this just adds commands/snippets in bundle (or replaces those with same name)
# many ruby files could add to a single bundle
bundle do |bundle|
  bundle.author = ""
  bundle.copyright = ""
  bundle.display_name = t(:bundle_name)
  bundle.description = "wx bundle for RadRails"
  bundle.repository = ""
  
end
