# JSON bundle for Aptana Studio

A bundle to enable related commands in Aptana Studio. Ported from http://github.com/textmate/json.tmbundle, which is a mirror of http://svn.textmate.org/trunk/Bundles/JSON.tmbundle/.

## Authors

* TextMate Contributors
* Modifications by Aptana

## License

This bundle is licensed under the TextMate license, available here:

* [TextMate license](http://svn.textmate.org/trunk/LICENSE)

## Bugs/Requests

* You can [report a bug or request a feature here](http://github.com/aptana/js.ruble/issues)